<?php


trait traitMovieng
{
    public function run($speed)
    {
        echo 'speed '. $speed;
    }
}