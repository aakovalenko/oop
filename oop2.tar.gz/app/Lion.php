<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 12:01
 */

namespace App;


class Lion extends Animal
{
    public function eat(FoodInterface $food){
        $this->health = $this->getHealth() + $food->getHealth()/2;
    }
}