<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 15.02.18
 * Time: 15:15
 */

namespace app;


class Bear
{
    use \traitMovieng;
}