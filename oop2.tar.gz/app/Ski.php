<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 15.02.18
 * Time: 14:05
 */

namespace App;


class Ski implements \IMovable
{

    private $speed = 0;

    public function start()
    {
        $this->setSpeed(5);
    }

    public function setSpeed($speed)
    {
        $this->speed = $speed;
    }

    public function stop()
    {
        $this->setSpeed(0);
    }

    public function getSpeed()
    {
        echo $this->speed;
    }
}