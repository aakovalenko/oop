<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 13.02.18
 * Time: 17:26
 */

namespace App;


class Flower implements FoodInterface
{
    use HealthTrait;

    public $health;

    public function __construct($health)
    {
        $this->health = $health;
    }


}