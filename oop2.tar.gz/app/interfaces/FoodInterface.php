<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 13.02.18
 * Time: 17:29
 */

namespace App;

interface FoodInterface
{
    public function getHealth():int;
}