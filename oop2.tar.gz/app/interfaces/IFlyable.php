<?php

interface IFlyable
{
    public function fly();
}