<?php


interface IDriftable extends IMovable
{
    public function setCorner();
}