<?php


interface IDragable extends IDriftable
{
   public function blockDifference();

   public function useNO2();
}