<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 13.02.18
 * Time: 15:40
 */
namespace App;

class Dog
{
    public $name;
    public $weight;
    public $legsCount;
    private $isAlive = true;
    protected static $bioType = 'Animal';

    public function __construct($name, $weight, $legsCount = 4)
    {
        $this->name = $name;
        $this->weight = $weight;
        $this->legsCount = $legsCount;
    }

    public function run(){
        if($this->isAlive){
            return $this->legsCount / $this->weight;
        }
        throw new Exception('This dog is not alive');
    }

    public static function getBioType(){
        return static::$bioType;
    }
}