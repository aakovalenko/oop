<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 12:05
 */

namespace App;

use App\Animal;

class Oak extends Amimals
{
    public function eat(FoodInterface $food){
        $this->health = $this->getHealth() + $food->getHealth();
    }
}