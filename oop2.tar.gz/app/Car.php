<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 12:23
 */

namespace App;


abstract class Car
{
    protected $brand;
    protected $color;
    private $maxSpeed;
    public $currentSpeed = 0;

    const MAX_LIFTING_CAPACITY = 630;

    public static $_counterOfCars = 0;

    public function __construct($brand, $color = 'dark sky', $maxSpeed)
    {
        $this->brand = $brand;
        $this->color = $color;
        $this->maxSpeed = $maxSpeed;
        self::$_counterOfCars++;
    }

    abstract public function getDynamic();


    public static function getCarWithrandomMaxSpeed()
    {
        return new Car('Cadillac','green',rand(200,250));
    }

    public function move($speed){}

    public function stop(){}

    public function setSpeed($speed)
    {
        $this->currentSpeed = $speed;
    }

    public function getColor()
    {
       return $this->color;
    }

    public function bar()
    {
        echo __CLASS__;
    }


}