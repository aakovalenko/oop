<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 15.02.18
 * Time: 14:10
 */

namespace App;


class Human
{
    use \traitMovieng;

    public function drive(\IMovable $IMovableObject)
    {
        $IMovableObject->start();
    }


}