<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 14:34
 */

namespace App;


class Bmw extends Car
{

}