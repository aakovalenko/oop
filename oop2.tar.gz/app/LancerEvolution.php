<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 14:54
 */

namespace App;


class LancerEvolution extends Mitsubishi
{
     public $tireLifeTime = 60;

     public function drift()
     {
        $this->tireLifeTime = $this->tireLifeTime - 5;
     }

     public function dynamic()
     {
         // TODO: Implement dynamic() method.

     }


}