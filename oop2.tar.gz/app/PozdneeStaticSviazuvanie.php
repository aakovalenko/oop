<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 16.02.18
 * Time: 12:44
 */

namespace app;


class A
{
     public static $iAm = 'class A';

     public function selfMe()
     {
         echo self::$iAm;
     }

     public function staticMe()
     {
         echo static::$iAm;
     }
}

class B extends A
{
    public static $iA = 'class B';
}

$b = new B();

$b->selfMe(); // выведет class A

$b->staticMe(); // выведет class B (сначала буде тсмотреть свойства в классе В)