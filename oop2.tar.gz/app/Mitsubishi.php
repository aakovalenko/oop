<?php
/**
 * Created by PhpStorm.
 * User: andrii
 * Date: 14.02.18
 * Time: 14:34
 */

namespace App;


class Mitsubishi extends Car implements \IDragable
{
    public $sign = 'M';

    public function __construct()
    {
        parent::__construct($brand="Mitsubishi",'yellow',230);
    }

    public function changeBrand()
    {
        $this->brand = 'gg0';
    }

    public function setColor($color)
    {
        if ($this->currentSpeed == 0)
        {
            $this->color = $color.'_'.$this->sign;
        }

    }

    public function getColor()
    {
        return $this->color;
    }

    public function bar()
    {
        parent::bar();
        echo '*****';
        echo __CLASS__;
    }

    public function getDynamic()
    {
        echo '9,4 c до 100';
    }

    public function blockDifference()
    {
        echo 'block';
    }

    public function useNO2()
    {
        $this->setSpeed(600);
    }

    public function start()
    {

    }

    public function setCorner()
    {

    }

}