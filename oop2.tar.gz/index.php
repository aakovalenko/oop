<?php

require_once 'vendor/autoload.php';
/*
function __autoload($class)
{
   require_once $class.'.php';
}*/

/*use App\Lion;
use App\Animal;
use App\Flower;
use App\Oak;



$oak = new Oak(100, 100);

$flower = new Flower(50);

$lion = new Lion(100, 150);

echo 'Oak health: '.$oak->getHealth();

$oak->eat($flower);

echo '<br>Oak health: '.$oak->getHealth();

$lion->eat($oak);

echo '<br>Lion health: '.$lion->getHealth();*/
use App\Car;
use App\Ski;
use App\Human;
use App\Bear;

/*$car = new Car('BMW','red',300);
$car2 = new Car('Honda', 'dark-red','280');
$car3 = new Car('Lexus','white','275');

$car4 = $car;



echo Car::$_counterOfCars.PHP_EOL;

$newCadi = Car::getCarWithrandomMaxSpeed();

print_r($newCadi).PHP_EOL;
echo '<hr/>';
print_r($car4);
echo '<br/>';
print_r($car);*/

/*function salesManagerDo ($variable)
{
    if ($variable == 0)
    {
        throw new Exception('user 1 send 0');

    }
}

try{
    salesManagerDo(5);
} catch (Exception $exception){
    echo $exception->getMessage();
} finally {
    echo 111111111111;
}

echo '<br/>'.'|******__________******|';*/


$mitsubishi = new \App\Mitsubishi();

$cloneMitsubishi = clone $mitsubishi;
var_dump($mitsubishi);

$array = [1,2,3,4,5];


$sArray = serialize($array);
unserialize($sArray);







