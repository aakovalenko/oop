<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 04/02/2018
 * Time: 17:48
 */

namespace App;


interface FoodInterface
{

    public function getHealth() :int;

}