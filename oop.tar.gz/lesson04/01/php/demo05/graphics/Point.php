<?php

namespace demo05\graphics;

interface Point {
    public function getDecartCoordinates();
}