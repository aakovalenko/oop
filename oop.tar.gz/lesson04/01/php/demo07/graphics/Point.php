<?php

namespace demo07\graphics;

interface Point {
    public function getDecartCoordinates();
}