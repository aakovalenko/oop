<?php

namespace demo08\graphics;

interface Point {
    public function getDecartCoordinates();
}