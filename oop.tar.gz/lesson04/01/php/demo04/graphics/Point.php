<?php

namespace demo04\graphics;

interface Point {
    public function getDecartCoordinates();
}