<?php

namespace demo06\graphics;

interface Point {
    public function getDecartCoordinates();
}